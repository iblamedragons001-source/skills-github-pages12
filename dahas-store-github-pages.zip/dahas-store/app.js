const PRODUCTS = [
 {id:"eliteflex",name:"Elite-Flex Stretch T-Shirt",category:"Shirts",price:1650,old:3100,colors:[["Maroon","#7a1f3d"],["Ocean Blue","#1f6f9c"],["Sage","#9caf88"],["Skin","#e2c3a5"]],sizes:["S","M","L"],type:"tee"},
 {id:"mesh",name:"EliteFlex Stretch Mesh T-Shirt",category:"Shirts",price:1650,old:3100,colors:[["Black","#171717"],["Dark Blue","#1c2a4a"],["Dark Green","#1f4a36"],["Skin","#e2c3a5"]],sizes:["S","M","L"],type:"tee"},
 {id:"quickdry",name:"Premium Stretch Quick-Dry Plain T-Shirt",category:"Shirts",price:1590,old:2990,colors:[["Black","#171717"],["White","#f3f0e9"]],sizes:["S","M","L","XL","XXL","XXXL"],type:"tee"},
 {id:"waffle",name:"Premium Stretchable Waffle-Knit T-Shirt",category:"Shirts",price:2450,old:3550,colors:[["Black","#171717"],["Brown","#6b4a34"],["Pink","#e8a0b4"],["Sage","#9caf88"],["White","#f3f0e9"]],sizes:["L"],type:"tee"},
 {id:"polo",name:"Men's Imported Premium Polo T-Shirt",category:"Shirts",price:2290,old:3500,colors:[["Green","#3f7a4a"],["Orange","#e0662a"],["Red","#b5232b"]],sizes:["M","L","XL","XXL"],type:"polo"},
 {id:"tracksuit",name:"Men's Collar Button-up Tracksuit",category:"Sets",price:2990,colors:[["Brown","#6b4a34"],["Dark Green","#1f4a36"],["Dark Purple","#4a1f55"],["Yellow","#e3b52a"]],sizes:["M","L","XL"],type:"set"},
 {id:"trouser",name:"Premium-Stretch Contrast-Panel Dahas-Printed Trouser",category:"Trousers",price:1860,old:3100,colors:[["Black","#171717"],["Dark Blue","#1c2a4a"],["Gray","#7a7d84"],["Maroon","#7a1f3d"],["Olive","#6b6b3a"]],sizes:["S","M","L"],type:"trouser"},
 {id:"cargo",name:"Men's Denim Acid-wash Cargo Trouser",category:"Trousers",price:2390,old:3450,colors:[["Denim Blue","#3d5a80"]],sizes:["W/30","W/32","W/34","W/36","W/38"],type:"trouser"}
];
const money = n => "₨ " + Number(n).toLocaleString("en-PK");
const state = {cart: JSON.parse(localStorage.getItem("dahas-cart") || "[]"), filter:"All"};
const $ = s => document.querySelector(s);
function productArt(p,color){
 const fill=color || p.colors[0][1];
 const shape = p.type==="trouser"
 ? `<path d="M38 15h44l-5 34-4 42H53l-4-37-4 37H28l-1-42z" fill="${fill}" stroke="#171714" stroke-opacity=".16" stroke-width="1.5"/><path d="M38 16h44M49 52h26" stroke="#fff" stroke-opacity=".35" stroke-width="2"/>`
 : p.type==="set"
 ? `<path d="M34 15l16-6h20l16 6 10 19-12 7-7-10v62H27V31l-7 10-12-7 10-19 16-6z" fill="${fill}" stroke="#171714" stroke-opacity=".18" stroke-width="1.5"/><path d="M36 14l14 12 14-12M50 26v58" fill="none" stroke="#fff" stroke-opacity=".35" stroke-width="2"/><path d="M37 86l-4 8h17V86m13 0v8h17l-4-8" fill="${fill}"/>`
 : `<path d="M34 15l16-6h20l16 6 10 19-12 7-7-10v62H27V31l-7 10-12-7 10-19 16-6z" fill="${fill}" stroke="#171714" stroke-opacity=".18" stroke-width="1.5"/><path d="M36 14l14 12 14-12" fill="none" stroke="#fff" stroke-opacity=".4" stroke-width="2"/>`;
 return `<svg viewBox="0 0 100 110" aria-hidden="true">${shape}</svg>`;
}
function save(){localStorage.setItem("dahas-cart",JSON.stringify(state.cart));}
function renderProducts(){
 $("#productGrid").innerHTML=PRODUCTS.filter(p=>state.filter==="All"||p.category===state.filter).map(p=>`
 <article class="product-card"><div class="product-visual">${productArt(p)}${p.old?'<span class="product-tag">SPECIAL PRICE</span>':''}<button class="quick-add" data-add="${p.id}">Quick add +</button></div>
 <div class="product-info"><h3>${p.name}</h3><div class="product-meta"><span>${p.old?`<s>${money(p.old)}</s> `:""}${money(p.price)}</span><span>${p.category}</span></div><div class="product-colours">${p.colors.map(c=>`<i class="swatch" title="${c[0]}" style="background:${c[1]}"></i>`).join("")}</div></div></article>`).join("");
}
function add(id){
 const p=PRODUCTS.find(x=>x.id===id);if(!p)return;
 const key=id+"|"+p.colors[0][0]+"|"+p.sizes[0],found=state.cart.find(x=>x.key===key);
 if(found)found.qty++;else state.cart.push({key,id,color:p.colors[0][0],size:p.sizes[0],qty:1});
 save();renderCart();toast("Added to your bag");
}
function renderCart(){
 const count=state.cart.reduce((n,x)=>n+x.qty,0),total=state.cart.reduce((n,x)=>n+PRODUCTS.find(p=>p.id===x.id).price*x.qty,0);
 $("#cartCount").textContent=count;$("#subtotal").textContent=money(total);$("#checkoutTotal").textContent=money(total);
 $("#cartItems").innerHTML=state.cart.length?state.cart.map(x=>{const p=PRODUCTS.find(p=>p.id===x.id);return `<div class="cart-row"><div class="mini-art">${productArt(p,p.colors.find(c=>c[0]===x.color)?.[1])}</div><div><h4>${p.name}</h4><p>${x.color} · ${x.size}</p><div class="qty"><button data-qty="${x.key}" data-delta="-1">−</button><span>${x.qty}</span><button data-qty="${x.key}" data-delta="1">+</button></div><button class="remove" data-remove="${x.key}">Remove</button></div><strong>${money(p.price*x.qty)}</strong></div>`}).join(""):'<div class="empty-bag">Your bag is waiting for something good.</div>';
}
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function openCart(){ $("#cartDrawer").classList.add("open");$("#overlay").classList.add("show");$("#cartDrawer").setAttribute("aria-hidden","false");}
function closeCart(){ $("#cartDrawer").classList.remove("open");$("#overlay").classList.remove("show");$("#cartDrawer").setAttribute("aria-hidden","true");}
$("#productGrid").addEventListener("click",e=>{const b=e.target.closest("[data-add]");if(b)add(b.dataset.add)});
$("#filters").addEventListener("click",e=>{const b=e.target.closest("[data-filter]");if(!b)return;state.filter=b.dataset.filter;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));renderProducts()});
$("#openCart").onclick=openCart;$("#closeCart").onclick=closeCart;$("#overlay").onclick=closeCart;
$("#cartItems").addEventListener("click",e=>{
 const r=e.target.closest("[data-remove]");if(r){state.cart=state.cart.filter(x=>x.key!==r.dataset.remove);save();renderCart();return}
 const q=e.target.closest("[data-qty]");if(q){const item=state.cart.find(x=>x.key===q.dataset.qty);item.qty+=Number(q.dataset.delta);if(item.qty<1)state.cart=state.cart.filter(x=>x!==item);save();renderCart()}
});
$("#checkoutButton").onclick=()=>{if(!state.cart.length){toast("Your bag is empty");return}closeCart();$("#checkoutModal").classList.add("open");$("#checkoutModal").setAttribute("aria-hidden","false")};
$("#closeCheckout").onclick=()=>{$("#checkoutModal").classList.remove("open");$("#checkoutModal").setAttribute("aria-hidden","true")};
$("#checkoutForm").addEventListener("submit",async e=>{
 e.preventDefault();if(!state.cart.length){toast("Your bag is empty");return}
 const endpoint=window.DAHAS_CONFIG?.paymentEndpoint;
 if(!endpoint){$("#formMessage").textContent="Online payment is not connected yet. Add your secure payment backend URL in config.js after merchant onboarding. No order or payment has been submitted.";toast("Payment gateway setup is still required");return}
 const form=Object.fromEntries(new FormData(e.currentTarget).entries());
 const order={customer:form,items:state.cart.map(x=>({...x,product:PRODUCTS.find(p=>p.id===x.id).name,unitPrice:PRODUCTS.find(p=>p.id===x.id).price})),currency:"PKR"};
 const button=e.currentTarget.querySelector('button[type="submit"]');button.disabled=true;button.textContent="Connecting securely…";
 try{const res=await fetch(endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(order)});const data=await res.json();if(!res.ok||!data.checkoutUrl)throw new Error(data.message||"Could not start payment");window.location.assign(data.checkoutUrl)}
 catch(err){$("#formMessage").textContent=err.message||"Payment could not be started. Please try again.";button.disabled=false;button.innerHTML='Continue to secure payment <span>↗</span>'}
});
$("#menuToggle").onclick=()=>$("#mainNav").classList.toggle("open");
document.querySelectorAll("#mainNav a").forEach(a=>a.addEventListener("click",()=>$("#mainNav").classList.remove("open")));
renderProducts();renderCart();
