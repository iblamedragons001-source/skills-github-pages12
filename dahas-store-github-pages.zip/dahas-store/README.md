# DAHAS storefront starter

A responsive, static storefront designed for GitHub Pages. Product browsing, category filters, bag quantity controls, saved cart, and checkout form UI work in the browser.

## Important: online payments are not live yet

GitHub Pages only hosts static files. The checkout form intentionally does **not** pretend to accept money. It will show a setup message until a secure backend is connected.

Suggested next integration: Safepay Express Checkout. Their documented flow creates a payment tracker and auth token on your server, redirects the shopper to hosted checkout, and uses a webhook to confirm the final payment state. Keep all merchant secret keys on the server, never in `app.js`, `config.js`, or GitHub Pages.

Official documentation:
- https://safepay.pk/
- https://safepay.alihamas.pk/docs/payments/get-started/express-checkout
- https://safepay.alihamas.pk/docs/payments/get-started/integration-checklist

## Preview locally

Open `index.html` in a browser, or use a local static server.

## Publish on GitHub Pages

1. Create a GitHub repository for the storefront.
2. Upload `index.html`, `styles.css`, `app.js`, `config.js`, and the `assets` folder.
3. In repository Settings → Pages, select Deploy from a branch and choose `main` / root.
4. Wait for the published URL shown by GitHub Pages.

## Connect payments later

1. The business owner / authorized adult should complete payment-provider merchant onboarding and obtain sandbox credentials.
2. Deploy a backend (for example a serverless function) that validates the submitted cart against trusted server-side product prices, creates the payment session, and returns `{ "checkoutUrl": "https://..." }`.
3. Verify payment status with a signed provider webhook before marking an order as paid.
4. Set `window.DAHAS_CONFIG.paymentEndpoint` in `config.js` to the backend URL.
5. Test success, failure, cancellation, duplicate webhook delivery, and amount tampering before going live.

## Product content

The initial catalog and prices are based on the details in the supplied Dahas code. Confirm all product names, prices, sizes, colour availability, sale prices, shipping policy, and contact details before launch.

## Current limitations

- Product artwork is abstract CSS/SVG placeholder artwork, not actual garment photography.
- Product cards quick-add the first available colour and size. A product detail selector should be added before production.
- No admin dashboard, inventory sync, order database, transactional email, or real payment processing is included yet.
- Prices in the browser are display-only. The backend must calculate totals from its own trusted catalog.
