/*
  Set this only after deploying a secure server-side payment endpoint.
  Example: window.DAHAS_CONFIG = { paymentEndpoint: "https://your-api.example.com/create-checkout" };
  Never put payment secret keys in this file or in GitHub Pages.
*/
window.DAHAS_CONFIG = {
  paymentEndpoint: ""
};
